# MoneyTracker
Moneytracker for the course 5-Software Design. Made by Ruben Nietvelt and Wout Van Uytsel.
You can use the gui to navigate through the moneytracker.
