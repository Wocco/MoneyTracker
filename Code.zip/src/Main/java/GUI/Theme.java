package GUI;

public interface Theme {
    public void changeTheme(ThemeContext themeContext);
}
